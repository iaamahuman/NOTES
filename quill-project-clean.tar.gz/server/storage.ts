import { type User, type InsertUser, type Note, type InsertNote, type NoteWithUploader } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Note operations
  getNote(id: string): Promise<Note | undefined>;
  getNoteWithUploader(id: string): Promise<NoteWithUploader | undefined>;
  getAllNotes(): Promise<NoteWithUploader[]>;
  getNotesBySubject(subject: string): Promise<NoteWithUploader[]>;
  searchNotes(query: string): Promise<NoteWithUploader[]>;
  getFeaturedNotes(): Promise<NoteWithUploader[]>;
  getRecentNotes(): Promise<NoteWithUploader[]>;
  createNote(note: InsertNote): Promise<Note>;
  incrementDownloads(id: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private notes: Map<string, Note>;

  constructor() {
    this.users = new Map();
    this.notes = new Map();
    
    // Create a sample user for development
    const sampleUser: User = {
      id: "sample-user-id",
      username: "alexchen",
      email: "alex@example.com",
      password: "hashedpassword",
      createdAt: new Date(),
    };
    this.users.set(sampleUser.id, sampleUser);
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async getNote(id: string): Promise<Note | undefined> {
    return this.notes.get(id);
  }

  async getNoteWithUploader(id: string): Promise<NoteWithUploader | undefined> {
    const note = this.notes.get(id);
    if (!note) return undefined;

    const uploader = await this.getUser(note.uploaderId);
    if (!uploader) return undefined;

    return {
      ...note,
      uploader: {
        username: uploader.username,
        id: uploader.id,
      },
    };
  }

  async getAllNotes(): Promise<NoteWithUploader[]> {
    const notesArray = Array.from(this.notes.values());
    const notesWithUploaders: NoteWithUploader[] = [];

    for (const note of notesArray) {
      const uploader = await this.getUser(note.uploaderId);
      if (uploader) {
        notesWithUploaders.push({
          ...note,
          uploader: {
            username: uploader.username,
            id: uploader.id,
          },
        });
      }
    }

    return notesWithUploaders.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getNotesBySubject(subject: string): Promise<NoteWithUploader[]> {
    const allNotes = await this.getAllNotes();
    return allNotes.filter(note => note.subject.toLowerCase() === subject.toLowerCase());
  }

  async searchNotes(query: string): Promise<NoteWithUploader[]> {
    const allNotes = await this.getAllNotes();
    const searchTerm = query.toLowerCase();
    
    return allNotes.filter(note => 
      note.title.toLowerCase().includes(searchTerm) ||
      note.description?.toLowerCase().includes(searchTerm) ||
      note.subject.toLowerCase().includes(searchTerm)
    );
  }

  async getFeaturedNotes(): Promise<NoteWithUploader[]> {
    const allNotes = await this.getAllNotes();
    return allNotes
      .filter(note => parseFloat(note.rating || '0') >= 4.5 || note.downloads > 100)
      .slice(0, 6);
  }

  async getRecentNotes(): Promise<NoteWithUploader[]> {
    const allNotes = await this.getAllNotes();
    return allNotes.slice(0, 8);
  }

  async createNote(insertNote: InsertNote): Promise<Note> {
    const id = randomUUID();
    const note: Note = {
      ...insertNote,
      description: insertNote.description || null,
      id,
      downloads: 0,
      rating: "0.00",
      ratingCount: 0,
      createdAt: new Date(),
    };
    this.notes.set(id, note);
    return note;
  }

  async incrementDownloads(id: string): Promise<void> {
    const note = this.notes.get(id);
    if (note) {
      note.downloads = note.downloads + 1;
      this.notes.set(id, note);
    }
  }
}

export const storage = new MemStorage();
